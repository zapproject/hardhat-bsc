import { EnvironmentExtender } from "../../../types";
export declare class ExtenderManager {
    private readonly _extenders;
    add(extender: EnvironmentExtender): void;
    getExtenders(): EnvironmentExtender[];
}
//# sourceMappingURL=extenders.d.ts.map