export declare function isCwdInsideProject(): boolean;
export declare function getUserConfigPath(): string;
export declare function getRecommendedGitIgnore(): Promise<string>;
//# sourceMappingURL=project-structure.d.ts.map