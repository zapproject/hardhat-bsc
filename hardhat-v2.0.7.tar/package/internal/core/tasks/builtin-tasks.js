"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("../../../builtin-tasks/check");
require("../../../builtin-tasks/clean");
require("../../../builtin-tasks/compile");
require("../../../builtin-tasks/console");
require("../../../builtin-tasks/flatten");
require("../../../builtin-tasks/help");
require("../../../builtin-tasks/node");
require("../../../builtin-tasks/run");
require("../../../builtin-tasks/test");
//# sourceMappingURL=builtin-tasks.js.map