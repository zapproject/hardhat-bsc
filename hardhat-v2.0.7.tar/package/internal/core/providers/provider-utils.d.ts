export declare function rpcQuantityToNumber(quantity?: string): number;
export declare function numberToRpcQuantity(n: number): string;
//# sourceMappingURL=provider-utils.d.ts.map