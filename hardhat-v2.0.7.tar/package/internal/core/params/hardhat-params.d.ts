import { HardhatParamDefinitions } from "../../../types";
export declare const HARDHAT_PARAM_DEFINITIONS: HardhatParamDefinitions;
//# sourceMappingURL=hardhat-params.d.ts.map