export declare function resetHardhatContext(): void;
//# sourceMappingURL=reset.d.ts.map