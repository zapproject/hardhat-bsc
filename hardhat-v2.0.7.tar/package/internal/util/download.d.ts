export declare function download(url: string, filePath: string, timeoutMillis?: number): Promise<void>;
//# sourceMappingURL=download.d.ts.map