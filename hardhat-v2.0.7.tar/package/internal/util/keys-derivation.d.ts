/// <reference types="node" />
export declare function deriveKeyFromMnemonicAndPath(mnemonic: string, hdPath: string): Buffer | undefined;
//# sourceMappingURL=keys-derivation.d.ts.map