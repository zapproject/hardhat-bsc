export declare function getRequireCachedFiles(): string[];
//# sourceMappingURL=platform.d.ts.map