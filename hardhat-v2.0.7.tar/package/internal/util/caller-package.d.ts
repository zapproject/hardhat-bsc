/**
 * Returns the name of the closest package in the callstack that isn't this.
 */
export declare function getClosestCallerPackage(): string | undefined;
//# sourceMappingURL=caller-package.d.ts.map