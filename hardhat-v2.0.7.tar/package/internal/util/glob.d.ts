import type { IOptions as GlobOptions } from "glob";
export declare function glob(pattern: string, options?: GlobOptions): Promise<string[]>;
export declare function globSync(pattern: string, options?: GlobOptions): string[];
//# sourceMappingURL=glob.d.ts.map