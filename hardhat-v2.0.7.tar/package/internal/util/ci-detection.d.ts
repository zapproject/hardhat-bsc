export declare function isRunningOnCiServer(): boolean;
//# sourceMappingURL=ci-detection.d.ts.map