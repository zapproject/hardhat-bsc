export declare function parseDateString(str: string): Date;
export declare function dateToTimestampSeconds(date: Date): number;
export declare function getDifferenceInSeconds(a: Date, b: Date): number;
//# sourceMappingURL=date.d.ts.map