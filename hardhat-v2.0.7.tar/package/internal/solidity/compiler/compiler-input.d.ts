import { CompilationJob, CompilerInput } from "../../../types";
export declare function getInputFromCompilationJob(compilationJob: CompilationJob): CompilerInput;
//# sourceMappingURL=compiler-input.d.ts.map