export declare function getSubprocessTransport(): any;
//# sourceMappingURL=transport.d.ts.map