export {};
//# sourceMappingURL=subprocess.d.ts.map