import { HardhatRuntimeEnvironment } from "../../types";
declare let env: HardhatRuntimeEnvironment;
export = env;
//# sourceMappingURL=hardhat-lib.d.ts.map