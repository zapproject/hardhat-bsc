export declare function createProject(): Promise<void>;
export declare function confirmTelemetryConsent(): Promise<boolean | undefined>;
//# sourceMappingURL=project-creation.d.ts.map