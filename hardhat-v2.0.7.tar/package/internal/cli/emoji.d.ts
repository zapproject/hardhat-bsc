export declare function enableEmoji(): void;
export declare function emoji(msgIfEnabled: string, msgIfDisabled?: string): string;
//# sourceMappingURL=emoji.d.ts.map