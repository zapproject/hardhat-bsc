export declare function isHexPrefixed(value: string): boolean;
//# sourceMappingURL=isHexPrefixed.d.ts.map