import { NetworkConfig } from "../../../../types";
export declare function showForkRecommendationsBannerIfNecessary(currentNetworkConfig: NetworkConfig, forkCachePath: string): Promise<void>;
//# sourceMappingURL=fork-recomendations-banner.d.ts.map