import { ProjectPathsConfig } from "../../../../types";
export declare function getForkCacheDirPath(paths: ProjectPathsConfig): string;
//# sourceMappingURL=disk-cache.d.ts.map