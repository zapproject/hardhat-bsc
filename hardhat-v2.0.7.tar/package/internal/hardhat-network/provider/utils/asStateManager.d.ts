import { ForkStateManager } from "../fork/ForkStateManager";
import { StateManager } from "../types/StateManager";
export declare function asStateManager(stateManager: StateManager | ForkStateManager): StateManager;
//# sourceMappingURL=asStateManager.d.ts.map