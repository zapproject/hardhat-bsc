export declare function getCurrentTimestamp(): number;
//# sourceMappingURL=getCurrentTimestamp.d.ts.map