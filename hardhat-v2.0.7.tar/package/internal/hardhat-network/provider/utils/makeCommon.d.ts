import Common from "ethereumjs-common";
import { LocalNodeConfig } from "../node-types";
export declare function makeCommon({ initialDate, chainId, networkId, networkName, blockGasLimit, hardfork, }: LocalNodeConfig, stateTrie: any): Common;
//# sourceMappingURL=makeCommon.d.ts.map