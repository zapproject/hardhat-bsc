"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentTimestamp = void 0;
function getCurrentTimestamp() {
    return Math.ceil(new Date().getTime() / 1000);
}
exports.getCurrentTimestamp = getCurrentTimestamp;
//# sourceMappingURL=getCurrentTimestamp.js.map