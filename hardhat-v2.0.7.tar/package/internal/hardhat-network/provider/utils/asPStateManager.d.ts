import { StateManager } from "@nomiclabs/ethereumjs-vm/dist/state";
import { ForkStateManager } from "../fork/ForkStateManager";
import { PStateManager } from "../types/PStateManager";
export declare function asPStateManager(stateManager: StateManager | ForkStateManager): PStateManager;
//# sourceMappingURL=asPStateManager.d.ts.map