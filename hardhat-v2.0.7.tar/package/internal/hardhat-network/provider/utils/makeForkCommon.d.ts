import Common from "ethereumjs-common";
import { ForkedNodeConfig } from "../node-types";
export declare function makeForkCommon(config: ForkedNodeConfig): Promise<Common>;
//# sourceMappingURL=makeForkCommon.d.ts.map