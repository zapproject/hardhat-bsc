import Common from "ethereumjs-common";
import { HardhatBlockchain } from "../HardhatBlockchain";
export declare function putGenesisBlock(blockchain: HardhatBlockchain, common: Common): Promise<void>;
//# sourceMappingURL=putGenesisBlock.d.ts.map