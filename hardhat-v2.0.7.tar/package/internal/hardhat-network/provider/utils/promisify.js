"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.promisify = void 0;
const util_1 = require("util");
exports.promisify = util_1.promisify;
//# sourceMappingURL=promisify.js.map