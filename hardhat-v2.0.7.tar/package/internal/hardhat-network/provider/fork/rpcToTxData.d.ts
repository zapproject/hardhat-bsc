import { TxData } from "ethereumjs-tx";
import { RpcTransaction } from "../../jsonrpc/types";
export declare function rpcToTxData(rpcTransaction: RpcTransaction): TxData;
//# sourceMappingURL=rpcToTxData.d.ts.map