/// <reference types="node" />
export declare const randomHash: () => string;
export declare const randomHashBuffer: () => Buffer;
export declare const randomAddress: () => string;
export declare const randomAddressBuffer: () => Buffer;
//# sourceMappingURL=random.d.ts.map