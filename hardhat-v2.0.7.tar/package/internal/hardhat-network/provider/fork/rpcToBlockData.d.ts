import { RpcBlockWithTransactions } from "../../jsonrpc/types";
import { BlockData } from "../types/Block";
export declare function rpcToBlockData(rpcBlock: RpcBlockWithTransactions): BlockData;
//# sourceMappingURL=rpcToBlockData.d.ts.map