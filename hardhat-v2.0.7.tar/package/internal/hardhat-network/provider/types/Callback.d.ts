export declare type Callback<T = void> = (error: Error | null, value: T) => void;
//# sourceMappingURL=Callback.d.ts.map