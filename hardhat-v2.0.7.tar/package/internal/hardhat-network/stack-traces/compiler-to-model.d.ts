import { CompilerInput, CompilerOutput } from "../../../types";
import { Bytecode } from "./model";
export declare function createModelsAndDecodeBytecodes(solcVersion: string, compilerInput: CompilerInput, compilerOutput: CompilerOutput): Bytecode[];
//# sourceMappingURL=compiler-to-model.d.ts.map