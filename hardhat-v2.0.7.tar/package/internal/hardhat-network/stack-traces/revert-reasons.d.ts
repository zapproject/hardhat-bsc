/// <reference types="node" />
export declare function decodeRevertReason(returnData: Buffer): string;
//# sourceMappingURL=revert-reasons.d.ts.map