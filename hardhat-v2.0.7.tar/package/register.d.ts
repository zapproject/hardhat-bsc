export {};
//# sourceMappingURL=register.d.ts.map