export function isHexPrefixed(value: string) {
  return value.toLowerCase().startsWith("0x");
}
