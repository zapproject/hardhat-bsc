export {};
//# sourceMappingURL=check.d.ts.map