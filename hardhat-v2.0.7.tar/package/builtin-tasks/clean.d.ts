export {};
//# sourceMappingURL=clean.d.ts.map