export {};
//# sourceMappingURL=console.d.ts.map