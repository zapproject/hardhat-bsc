export {};
//# sourceMappingURL=flatten.d.ts.map