import { EIP1193Provider, ProjectPathsConfig } from "../../types";
export declare function watchCompilerOutput(provider: EIP1193Provider, paths: ProjectPathsConfig): Promise<void>;
//# sourceMappingURL=watch.d.ts.map